# sdg-autovoice
Simple Discord Guild Autovoice Bot
