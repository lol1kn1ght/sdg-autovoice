export default {
  modules: {
    message_context: true,
    slash: true,
    user_context: true,
  },

  guild_id: '674657975264346142',
};
