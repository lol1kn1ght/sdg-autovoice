import { GuildSettingsType } from '#types';

/** @description Default settings for new guild */
export const GuildSettingsTemplate: GuildSettingsType = {
  commands_permissions: {
    aboba: {
      allowed_roles: ['dasdsadsad'],
    },
  },
};
