import { Message } from 'discord.js';

/** WIP */
export class Message_template {
  constructor(_message: Message) {}
}
